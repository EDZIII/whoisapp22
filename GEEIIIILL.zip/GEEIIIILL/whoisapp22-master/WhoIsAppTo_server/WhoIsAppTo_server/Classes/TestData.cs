﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WhoIsAppTo_server.Classes
{
	public class TestData
	{
		public string p1 { get; set; }
		public string p2 { get; set; }
		public string p3 { get; set; }
	}
}
