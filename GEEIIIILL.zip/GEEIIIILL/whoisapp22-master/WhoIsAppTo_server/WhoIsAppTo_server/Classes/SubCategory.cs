﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

//namespace WhoIsAppTo_server.Classes
//{
//	public class SubCategory
//	{
//		public string PrivateKey { get; set; }
//		public string SubCategoryName { get; set; }

//	}
//}
