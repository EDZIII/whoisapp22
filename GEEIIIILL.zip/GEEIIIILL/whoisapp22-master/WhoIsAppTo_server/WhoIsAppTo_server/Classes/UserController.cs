﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;

namespace WhoIsAppTo_server.Classes.json
{
	public class UserController
	{
		public void UserRegistration()
		{
			string dir = @"C:\Users\edocr\Desktop\whoisapp2new\whoisapp22\WhoIsAppTo_server\UserLog";
			
		}
	}
}
