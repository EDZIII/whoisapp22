﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WhoIsAppTo_server.Classes
{
	public class User
	{
		public string UserID{ get; set; }
		public string UserCredential { get; set; }
		public string UserDirectory { get; set; }
		//public IEnumerable<string> JoinedEventsID { get; set; }
		
public User()
		{

		}

	}
}
